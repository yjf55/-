#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
#include<string.h>
#define N 40
  typedef struct
  {
  char xingming[20];
  int xuehao[20];
  int score1;
  int score2;
  int score3;
  int score4;
  int score5;
  int score6;
  float av;
  int all;

  }student;

int  main()
  {
        printf("打印学生成绩单\n");
        printf("name\tscore1\tscore2\tscore3\tscore4\tscore5\tscore6\taverage\tall\n");
        int i;
        int p;
        int j=0;
        int m=0;
        student stu[N];
        srand((unsigned)time(NULL));         //为随机数设置种子.
 for(i=0;i<N;i++)
 {
        stu[i].score1=rand()%100+1;
        if(stu[i].score1<60)
        {
                j++;
                if(j>N/10)
                i--;
    }
         if(stu[i].score1>90)
         {
                m++;
                if(m>N/10)
                i--;
         }
         }//score1
         j=0;
         m=0;
for(i=0;i<N;i++)
 {
        stu[i].score2=rand()%100+1;
        if(stu[i].score2<60)
        {
                j++;
                if(j>N/10)
                i--;
         }
         if(stu[i].score2>90)
         {
                m++;
                if(m>N/10)
                i--;
         }
}//score2
         j=0,m=0;

         for(i=0;i<N;i++)
 {

        stu[i].score3=rand()%100+1;
        if(stu[i].score3<60)
        {
                j++;
                if(j>N/10)
                i--;
         }
         if(stu[i].score3>90)
         {
                m++;
                if(m>N/10)
                i--;

  }
  }// score 3
  j=0,m=0;
  for(i=0;i<N;i++)
 {
        stu[i].score4=rand()%100+1;
        if(stu[i].score4<60)
        {
                j++;
                if(j>N/10)
                i--;
         }
         if(stu[i].score4>90)
         {
                m++;
                if(m>N/10)
                i--;

  }
  }//score4
  j=0,m=0;
  for(i=0;i<N;i++)
 {
        stu[i].score5=rand()%100+1;
        if(stu[i].score5<60)
        {
                j++;
                if(j>N/10)
                i--;
         }
         if(stu[i].score5>90)
         {
                m++;
                if(m>N/10)
                i--;

  }
}//score 5
j=0,m=0;
  for(i=0;i<N;i++)
 {
        stu[i].score6=rand()%100+1;
        if(stu[i].score6<60)
        {
                j++;
                if(j>N/10)
                i--;
         }
         if(stu[i].score6>90)
         {
                m++;
                if(m>N/10)
                i--;

  }//score6
  }
  for(p=0;p<N;p++)
  {
  for(i=0;i<3;i++)
  {
        stu[p].xingming[i]='A'+(rand()%26);
  }
  stu[p].xingming[i]='\0';
}//随机赋值名字

         for(i=0;i<N;i++)
         {
                stu[i].av=(float)(stu[i].score1+stu[i].score2+stu[i].score3+stu[i].score4+stu[i].score5+stu[i].score6)/6;
         }
     for(i=0;i<N;i++)//计算平均值
     {
        stu[i].all=stu[i].score1+stu[i].score2+stu[i].score3+stu[i].score4+stu[i].score5+stu[i].score6;

         }//计算总成绩
          for(i=0;i<N;i++)
         {
                printf("%s\t%d\t%d\t%d\t%d\t%d\t%d\t%.2f\t%d\n",stu[i].xingming,stu[i].score1,stu[i].score2,stu[i].score3,stu[i].score4,stu[i].score5,stu[i].score6,stu[i].av,stu[i].all);
         }//打印没排序的程序
         printf("\n\n\n");
         printf("打印排序完毕的学生成绩单\n");
         for(i=0;i<N-1;i++)
         {
                for(j=0;j<N-1-i;j++)
                {
                        if(stu[j].all<stu[j+1].all)
                        {
                                student temp;
                                temp=stu[j];
                                stu[j]=stu[j+1];
                                stu[j+1]=temp;



                         }
                 }
         }//根据总程序进行结构体数组的互换
         printf("rank\tname\tscore1\tscore2\tscore3\tscore4\tscore5\tscore6\taverage\tall\n");
         for(i=0;i<N;i++)
         {
                printf("%d\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%.2f\t%d\n",i+1,stu[i].xingming,stu[i].score1,stu[i].score2,stu[i].score3,stu[i].score4,stu[i].score5,stu[i].score6,stu[i].av,stu[i].all);


         }//根据总程序打印排序完成后的结构体数组






 }
